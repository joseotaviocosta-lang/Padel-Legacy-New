import { DecisionEngine } from './DecisionEngine.js';
import { PositionEngine } from './PositionEngine.js';
import { FatigueEngine } from './FatigueEngine.js';
import { RallyMemory } from './RallyMemory.js';
import { createDecisionContext } from './DecisionContext.js';
import { recordShot, recordPoint, recordCoordination } from './StatisticsEngine.js';
import { TeamCoordinationEngine } from './TeamCoordinationEngine.js';

export class RallyEngine {
  constructor({ decision = new DecisionEngine(), position = new PositionEngine(), fatigue = new FatigueEngine(), coordination = new TeamCoordinationEngine() } = {}) {
    this.decision = decision;
    this.position = position;
    this.fatigue = fatigue;
    this.coordination = coordination;
  }

  play({ teams, servingTeam, tactic, random, stats, match = {} }) {
    let activeTeam = servingTeam;
    let playerIndex = Math.floor(random.next() * teams[activeTeam].length);
    let pressure = 20;
    let shot = 'serve';
    let lastPlayer = teams[activeTeam][playerIndex];
    const memory = new RallyMemory();
    const decisionTrace = [];
    const coordinationEvents = [];
    this.coordination.resetPoint(teams);

    for (let rallyLength = 1; rallyLength <= 60; rallyLength += 1) {
      const player = teams[activeTeam][playerIndex % teams[activeTeam].length];
      lastPlayer = player;
      let reasons = ['início do ponto'];
      if (rallyLength > 1) {
        const context = createDecisionContext({ player, teams, activeTeam, pressure, match, memory });
        const decision = this.decision.chooseDetailed({
          player,
          pressure,
          tactic: activeTeam === 'A' ? tactic : null,
          random,
          context,
        });
        shot = decision.shot;
        reasons = decision.reasons;
        decisionTrace.push({
          rallyLength,
          team: activeTeam,
          playerId: player.id,
          shot,
          reasons: reasons.slice(0, 4),
          context: {
            importantPoint: context.importantPoint,
            partnerTired: context.partnerTired,
            opponentAtNet: context.opponentAtNet,
            tiredOpponentEnergy: context.tiredOpponentEnergy,
          },
        });
      }

      const pointCoordination = this.coordination.coordinate({ teams, activeTeam, player, shot, rallyLength });
      pointCoordination.forEach((event) => {
        coordinationEvents.push({ rallyLength, ...event });
        recordCoordination(stats, event);
      });

      const finishingZone = player.position.zone;
      recordShot(stats, player, shot);
      this.fatigue.consume(player, shot, rallyLength);

      const skill = this.skill(player, shot);
      const confidence = (player.confidence - 50) * 0.14;
      const energyPenalty = (100 - player.energy) * 0.12;
      const risk = this.risk(shot, tactic, activeTeam === 'A', player, match);
      const execution = skill + confidence - energyPenalty - risk + (random.next() - 0.5) * 28;
      const difficulty = 38 + pressure * 0.28 + rallyLength * 0.18;

      memory.record({ team: activeTeam, playerId: player.id, shot, pressure, execution, difficulty });

      if (execution < difficulty) {
        const winner = activeTeam === 'A' ? 'B' : 'A';
        const forcedError = this.isForcedError({ pressure, execution, difficulty, rallyLength, memory });
        recordPoint(stats, winner, player, 'error', rallyLength, teams, {
          shot,
          zone: finishingZone,
          servingTeam,
          match,
          forcedError,
          pressure,
          execution,
          difficulty,
        });
        return {
          winner,
          finisher: player,
          shot,
          result: 'error',
          forcedError,
          rallyLength,
          pressure,
          execution,
          difficulty,
          match,
          decisionTrace,
          rallyMemory: memory.events,
          coordinationEvents,
        };
      }

      const winnerChance = Math.max(0.025, Math.min(0.42, (execution - difficulty) / 85 + this.winnerBonus(shot)));
      if (random.next() < winnerChance) {
        recordPoint(stats, activeTeam, player, 'winner', rallyLength, teams, {
          shot,
          zone: finishingZone,
          servingTeam,
          match,
          forcedError: false,
          pressure,
          execution,
          difficulty,
        });
        return {
          winner: activeTeam,
          finisher: player,
          shot,
          result: 'winner',
          forcedError: false,
          rallyLength,
          pressure,
          execution,
          difficulty,
          match,
          decisionTrace,
          rallyMemory: memory.events,
          coordinationEvents,
        };
      }

      const movement = this.position.afterShot(player, shot);
      const otherTeam = activeTeam === 'A' ? 'B' : 'A';
      this.position.applyOpponentZone(teams[otherTeam], movement.opponentZone);
      activeTeam = otherTeam;
      playerIndex += 1;
      pressure = Math.min(100, pressure + (['smash', 'volley', 'chiquita'].includes(shot) ? 10 : 4));
    }

    const winner = activeTeam === 'A' ? 'B' : 'A';
    recordPoint(stats, winner, lastPlayer, 'error', 60, teams, {
      shot,
      zone: lastPlayer.position.zone,
      servingTeam,
      match,
      forcedError: true,
      pressure: 100,
    });
    return {
      winner,
      finisher: lastPlayer,
      shot,
      result: 'error',
      forcedError: true,
      rallyLength: 60,
      pressure: 100,
      match,
      decisionTrace,
      rallyMemory: memory.events,
      coordinationEvents,
    };
  }

  isForcedError({ pressure, execution, difficulty, rallyLength, memory }) {
    const previous = memory.events[memory.events.length - 2];
    const previousAttack = previous && ['smash', 'volley', 'chiquita'].includes(previous.shot);
    const narrowFailure = difficulty - execution <= 8;
    return pressure >= 62 || rallyLength >= 12 || previousAttack || narrowFailure;
  }

  skill(player, shot) {
    const map = {
      serve: player.attributes.serve,
      drive: player.attributes.forehand,
      backhand: player.attributes.backhand,
      lob: (player.attributes.defense + player.attributes.strategy) / 2,
      volley: player.attributes.volley,
      bandeja: player.attributes.bandeja,
      smash: player.attributes.smash,
      chiquita: (player.attributes.forehand + player.attributes.strategy) / 2,
    };
    return map[shot] ?? player.overall;
  }

  risk(shot, tactic, isTeamA, player, match = {}) {
    let risk = { serve: 4, drive: 8, backhand: 7, lob: 6, volley: 8, bandeja: 7, smash: 16, chiquita: 12 }[shot] || 8;
    if (isTeamA && tactic?.id === 'defensivo') risk -= 3;
    if (isTeamA && ['agressivo', 'potencia'].includes(tactic?.id)) risk += 3;
    if (match.importantPoint && ['smash', 'chiquita'].includes(shot)) {
      const composure = Number(player.behavior?.tendencies?.pressure_resistance ?? 50);
      risk += (50 - composure) / 12;
    }
    return risk;
  }

  winnerBonus(shot) {
    return { smash: 0.14, volley: 0.08, drive: 0.05, chiquita: 0.04, bandeja: 0.03, serve: 0.035, lob: 0.015, backhand: 0.03 }[shot] || 0.03;
  }
}
