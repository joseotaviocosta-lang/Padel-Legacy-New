import React, { useMemo, useState } from 'react';
import { X, Crown, Trophy, MapPin, Users, Star, Coins, Clock3, BarChart3 } from 'lucide-react';

const TIER_STYLES = {
  Major: { badge: 'bg-amber-500/15 text-amber-300 border-amber-500/40', label: 'Major' },
  P1: { badge: 'bg-purple-500/15 text-purple-300 border-purple-500/30', label: 'P1' },
  P2: { badge: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30', label: 'P2' },
};

const LEGACY_TEAMS = [
  'Arturo Coello & Agustín Tapia',
  'Federico Chingotto & Paquito Navarro',
  'Franco Stupaczuk & Martín Di Nenno',
  'Alejandro Galán & Juan Lebrón',
  'Sanyo Gutiérrez & Fernando Belasteguín',
  'Pablo Lima & Juani Mieres',
  'Momo González & Álex Ruiz',
  'Juan Tello & Álex Arroyo',
];

function hashString(str) {
  let hash = 0;
  for (let i = 0; i < (str || '').length; i++) hash = ((hash << 5) - hash) + str.charCodeAt(i);
  return Math.abs(hash);
}

function normalizeTeamName(value) {
  if (!value) return 'Dupla não registrada';
  if (Array.isArray(value)) return value.filter(Boolean).join(' & ');
  const text = String(value).trim();
  return text.includes(' & ') ? text : `${text} & parceiro não registrado`;
}

function reconstructLegacyHistory(tournament) {
  const seed = hashString(`${tournament.name || ''}-${tournament.start_date || ''}`);
  const champion = normalizeTeamName(tournament.champion);
  const runnerUp = normalizeTeamName(tournament.runner_up || LEGACY_TEAMS[(seed + 1) % LEGACY_TEAMS.length]);
  const pool = LEGACY_TEAMS.filter(name => name !== champion && name !== runnerUp);
  const semiA = pool[seed % pool.length];
  const semiB = pool[(seed + 3) % pool.length];
  const quarterTeams = pool.slice(0, 4);

  return [
    {
      round: 'Quartas de final',
      matches: [
        { team_a: champion, team_b: quarterTeams[0], winner: champion, score: '6-3 6-4' },
        { team_a: semiA, team_b: quarterTeams[1], winner: semiA, score: '7-5 6-4' },
        { team_a: runnerUp, team_b: quarterTeams[2], winner: runnerUp, score: '6-4 6-2' },
        { team_a: semiB, team_b: quarterTeams[3], winner: semiB, score: '4-6 6-3 6-4' },
      ],
    },
    {
      round: 'Semifinais',
      matches: [
        { team_a: champion, team_b: semiA, winner: champion, score: '6-4 7-5' },
        { team_a: runnerUp, team_b: semiB, winner: runnerUp, score: '6-3 4-6 6-2' },
      ],
    },
    {
      round: 'Final',
      matches: [
        { team_a: champion, team_b: runnerUp, winner: champion, score: '6-4 6-3' },
      ],
    },
  ];
}

function normalizeHistory(tournament) {
  const raw = Array.isArray(tournament.bracket_history) && tournament.bracket_history.length
    ? tournament.bracket_history
    : reconstructLegacyHistory(tournament);

  return raw.map((round) => ({
    round: round.round || round.label || 'Rodada',
    matches: (round.matches || []).map((match) => ({
      ...match,
      team_a: normalizeTeamName(match.team_a || match.a),
      team_b: normalizeTeamName(match.team_b || match.b),
      winner: normalizeTeamName(match.winner),
      score: match.score || '—',
    })),
  }));
}

export default function TournamentBracket({ tournament, onClose }) {
  const tier = TIER_STYLES[tournament.tier] || TIER_STYLES.P2;
  const history = useMemo(() => normalizeHistory(tournament), [tournament]);
  const [activeRound, setActiveRound] = useState(Math.max(0, history.length - 1));
  const champion = normalizeTeamName(tournament.champion);
  const runnerUp = normalizeTeamName(tournament.runner_up || history.at(-1)?.matches?.[0]?.team_b);
  const matches = history.reduce((sum, round) => sum + round.matches.length, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/60 backdrop-blur-sm p-0 md:p-4" onClick={onClose}>
      <div className="glass rounded-t-3xl md:rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg font-black">{tournament.name}</h2>
            <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase ${tier.badge}`}>{tier.label}</span>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-5 w-5" /></button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
          <Info icon={MapPin} value={tournament.location?.split(',')[0] || '—'} color="text-cyan-400" />
          <Info icon={Star} value={tournament.sponsor || '—'} color="text-primary" />
          <Info icon={Users} value={(tournament.audience || 0).toLocaleString('pt-BR')} color="text-purple-400" />
          <Info icon={BarChart3} value={`${matches} partidas`} color="text-emerald-400" />
        </div>

        <div className="rounded-2xl border border-amber-500/40 bg-gradient-to-br from-amber-500/15 to-transparent p-4 mb-4 text-center">
          <Crown className="h-8 w-8 text-amber-400 mx-auto mb-2" />
          <p className="text-[10px] text-amber-400/70 uppercase font-bold tracking-wide">Campeões</p>
          <p className="text-lg font-black text-amber-300">{champion}</p>
          <p className="text-[10px] text-muted-foreground mt-1">Vice: {runnerUp}</p>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 mb-3">
          {history.map((round, index) => (
            <button
              key={`${round.round}-${index}`}
              onClick={() => setActiveRound(index)}
              className={`shrink-0 rounded-xl px-3 py-2 text-xs font-bold border transition-colors ${activeRound === index ? 'bg-primary text-primary-foreground border-primary' : 'bg-secondary/20 border-border/50 text-muted-foreground hover:text-foreground'}`}
            >
              {round.round}
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {(history[activeRound]?.matches || []).map((match, index) => (
            <MatchCard key={`${activeRound}-${index}`} match={match} number={index + 1} />
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4 pt-4 mt-4 border-t border-border/40">
          <div className="flex items-center gap-1.5"><Coins className="h-3.5 w-3.5 text-yellow-400" /><span className="text-xs font-bold">{(tournament.prize_coins || 0).toLocaleString('pt-BR')}</span><span className="text-[9px] text-muted-foreground uppercase">moedas</span></div>
          <div className="flex items-center gap-1.5"><Trophy className="h-3.5 w-3.5 text-amber-400" /><span className="text-xs font-bold">{tournament.rank_points || 0}</span><span className="text-[9px] text-muted-foreground uppercase">pts ranking</span></div>
          <div className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5 text-cyan-400" /><span className="text-xs font-bold">Histórico completo</span></div>
        </div>
      </div>
    </div>
  );
}

function Info({ icon: Icon, value, color }) {
  return <div className="text-center rounded-xl bg-secondary/30 p-2"><Icon className={`h-3.5 w-3.5 mx-auto mb-0.5 ${color}`} /><p className="text-[9px] font-bold truncate">{value}</p></div>;
}

function MatchCard({ match, number }) {
  const aWon = match.winner === match.team_a;
  const bWon = match.winner === match.team_b;
  return (
    <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
      <div className="flex items-center justify-between mb-2"><span className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Partida {number}</span><span className="text-[10px] font-mono text-muted-foreground">{match.score}</span></div>
      <TeamLine name={match.team_a} winner={aWon} />
      <TeamLine name={match.team_b} winner={bWon} />
    </div>
  );
}

function TeamLine({ name, winner }) {
  return (
    <div className={`flex items-center gap-2 rounded-lg px-2 py-2 mt-1 ${winner ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/20'}`}>
      <span className={`text-xs font-semibold flex-1 ${winner ? 'text-primary' : 'text-muted-foreground'}`}>{name}</span>
      {winner && <Crown className="h-3 w-3 text-amber-400" />}
    </div>
  );
}
